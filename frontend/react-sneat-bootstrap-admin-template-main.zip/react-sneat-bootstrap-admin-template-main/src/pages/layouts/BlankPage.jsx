import React from 'react'

export const BlankPage = () => {

    return (
        <h4 className="p-4">Blank Page</h4>
    )
}
